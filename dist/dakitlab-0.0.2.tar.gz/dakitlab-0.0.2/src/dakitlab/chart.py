class Chart:
    pass
